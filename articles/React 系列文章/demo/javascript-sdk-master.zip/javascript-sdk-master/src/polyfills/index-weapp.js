require('weapp-polyfill/auto-polyfill');
